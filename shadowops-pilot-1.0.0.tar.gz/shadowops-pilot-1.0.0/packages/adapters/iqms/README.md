# IQMS Adapter

IQMS adapter layer for ShadowOps. This package performs field mapping only and contains no business logic.
