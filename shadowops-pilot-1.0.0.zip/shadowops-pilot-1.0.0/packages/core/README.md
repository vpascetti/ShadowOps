# @shadowops/core

Canonical model, validation, and risk scoring for ShadowOps.
